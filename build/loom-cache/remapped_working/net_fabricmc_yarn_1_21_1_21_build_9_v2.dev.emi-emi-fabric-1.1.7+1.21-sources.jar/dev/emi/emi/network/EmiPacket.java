package dev.emi.emi.network;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.packet.CustomPayload;

public interface EmiPacket extends CustomPayload {
	void write(RegistryByteBuf buf);
	
	void apply(PlayerEntity player);
}
